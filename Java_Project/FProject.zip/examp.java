
abstract class examp {

	public abstract void infor();
	{
		System.out.println("this will hold user information");
	}
	public  examp()
	{
		System.out.println("for service data");
	}
}
