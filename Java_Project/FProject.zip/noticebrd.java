
public interface noticebrd {

	public void board();
	
	
}
